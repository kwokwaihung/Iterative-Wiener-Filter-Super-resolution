function output=ML_restoration(f,final,psf,m, im,fac )

% Maximum-likelihood restoration or Iterative back-projection

% f is input observed LR image
% final is estimated HR image
% psf is psf of imaging sytem
% m is the magnification factor
% im is the interpolation method
% fac is the step size
[sy,sx] =size(final);

fp = padconv2(final,psf,5);      %% blurred HR image
fp= fp(1:3:sy, 1:3:sx);          %% down-sample blurred image
fd = imresize(fp-f, m, im);      %%calculate the error (difference) and interpolate it
fd= fd(2:sy+1, 2:sx+1);          %%crop the interepoated image
output = final -fd.*fac;         %%add back to original

return;
