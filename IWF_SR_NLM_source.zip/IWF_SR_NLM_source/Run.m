% Kwok-Wai Hung, Wan-Chi Siu, Single-Image Super-Resolution Using Iterative Wiener Filter based on Nonlocal Means
%
% Module Leader: Prof. W.C. Siu, PhD, CEng, FIEE, FHKIE, FIEEE, Chair Professor
%
% PhD Researcher: Dr. K.W. Hung, PhD
%
% Version 1.0
% - Initial release
%
% 1). Please cite the following paper when you use the code:
%
%  Kwok-Wai Hung, Wan-Chi Siu, Single-Image Super-Resolution Using Iterative Wiener Filter based on Nonlocal Means, Signal Processing: Image Communication, Accepted for publication.
%
% 2). The current version of the program only support gray level image, 3x SR factor and noise variance 0-100.
%
% 3). This program support multi-threading, use the following commands if needed: matlabpool(7); %matlabpool close; parpool('local',7);


clear;
name='kodim08';         % name of HR image for simulation            
varN=0;                 % noise variance
PSF= ones(3,3)./9;      % PSF
noofiteration=9;        % number of iteration


I=imread(['Input\' name '.bmp'], 'bmp');
I=double(I); [sy,sx]= size(I);
I_blur=padconv2(I,PSF,5);
I_blur = imnoise(I_blur/255,'gaussian',0,varN*(1/255)^2);   % add gussian noise;
I_blur=I_blur*255; I_DS= I_blur(1:3:sy, 1:3:sx);            % 3X down-sampled of the blurred HR image

tic
I_DS=double(I_DS);
I_bic = imresize(I_DS, 3, 'Method', 'bicubic', 'Antialiasing', false);   % bicubic interpolation
I_bic= I_bic(2:sy+1, 2:sx+1);

if varN>0
    MLth=0.5;
else MLth=1;
end
I_IBP=ML_restoration(I_DS,I_bic,PSF,3, 'bicubic', MLth);     % IBP restoration
toc

imwrite(uint8(I_IBP),['Output\' name '_' 'IBP_noiseV_' int2str(varN) '.bmp']);
I_IBP=double(I_IBP);

pd=21;  % image padding
I_IBP=padimage_2(I_IBP, pd);
I_DS=padimage_2(I_DS,pd/3);

psnr= csnr(double((I_IBP(pd+1:sy+pd, pd+1:sx+pd))),double(uint8(I)),0,0)

alpha=4.5; 
tic

disp('Warning! This step requires several minutes to process. The processing time depends on your cpu speed and size of input image.');
for i=1:1:noofiteration
    disp(['The ' int2str(i) 'th iteration....']); 
    I_IBP=IWF_SR_NLM(I_DS,I_IBP,PSF, 16, 7 ,2.5*exp((i-1)^2/alpha) ,varN); 
    I_IBP=ML_restoration(I_DS,I_IBP,PSF,3, 'bicubic', MLth);
    imwrite(uint8(I_IBP(pd+1:sy+pd, pd+1:sx+pd)),['Output\' name '_iteration_' int2str(i) '.bmp']);
    psnr=[psnr csnr(double(uint8(I_IBP(pd+1:sy+pd, pd+1:sx+pd))),double(uint8(I)),0,0)];
    csvwrite(['Output\' name '_psnr_' 'varN_' int2str(varN) '_' '.txt'],psnr);  
end

elapsedTime = toc