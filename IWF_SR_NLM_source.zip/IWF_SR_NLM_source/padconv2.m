function output=padconv2(f,filter,pd)

% padded 2d convolution

% f is input image to be padded
% filter is convolution filter
% pd is number of pixels to be padded
[y,x]=size(f);

output= conv2(padimage_2(f,pd),filter,'same');        %% blur image
output= output(pd+1:y+pd, pd+1:x+pd);                 %% crop image

return;


