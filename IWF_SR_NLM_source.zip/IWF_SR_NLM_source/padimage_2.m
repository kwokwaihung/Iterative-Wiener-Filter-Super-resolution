function output=padimage_2(f,pd)

% f is input image to be padded
% pd is number of pixels to be padded
[y, x]= size(f);

output= [ rot90(f,2)  flipud(f)  rot90(f,2)
          fliplr(f)   f          fliplr(f)
          rot90(f,2)  flipud(f)  rot90(f,2)];

output= output(y+1-pd:y+y+pd, x+1-pd:x+x+pd);

return;

