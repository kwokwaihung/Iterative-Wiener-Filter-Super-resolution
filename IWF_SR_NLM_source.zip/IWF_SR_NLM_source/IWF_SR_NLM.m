function output=IWF_SR_NLM(f,final,psf, nfs,b,var, noiseV)

% f is input observed image
% final is estimated HR image
% psf is psf of blur
% nfs is number of samples within search window
% b is the block size
% var is the variance of correlation function
% noiseV is the noise variance of input image

[syy,sxx]= size(final);
sy=floor((syy-9)/3);
sx=floor((sxx-9)/3);

pd=0; ad=pd*2/3;
final=padimage_2(final, pd);
f=padimage_2(f,pd/3);

ff=padconv2(final,psf,5);

dd=1;
if b>8
    dd=1;
end
validy=zeros(sy+ad,sx+ad);

parfor yy=2+dd:1:sy+ad-dd
    y=yy*3+1;
    %     display(y);
    z=zeros(3,3,sx+ad);  valid16=zeros(1,sx+ad);
    for xx=2+dd:1:sx+ad-dd
        x=xx*3+1;
        
        %%build the auto- and cross-correlation
        rdf=zeros(16,9);
        coorf=[0 3 6 9 0 3 6 9 0 3 6 9 0 3 6 9
            0 0 0 0 3 3 3 3 6 6 6 6 9 9 9 9];
        coord=[3 4 5 3 4 5 3 4 5
            3 3 3 4 4 4 5 5 5];
        intenf= reshape(f((y-1)/3:1:(y-1)/3+3,(x-1)/3:1:(x-1)/3+3)', 1,16);
        
        variance= sum((intenf-mean(intenf)).^2)/16;
        if variance>2                               % proceed only if variance >2
            valid16(1,xx)=1;
            
            patchdiffA=zeros(16,1);
            for i=1:1:16
                j=5;
                patchdiff= ff(y-3+coorf(2,i)-3:1:y+3+coorf(2,i)-3,x-3+coorf(1,i)-3:1:x+3+coorf(1,i)-3) - final(y-3+coord(2,j)-3:1:y+3+coord(2,j)-3,x-3+coord(1,j)-3:1:x+3+coord(1,j)-3);
                patchdiffA(i,1) = sum(sum(patchdiff.*patchdiff));
            end
            
            % cut samples in 4x4 window if number of samples (nfs) <16
            if nfs~=16
                [~,sortI]=sort(patchdiffA);
                cp=sortI(nfs+1:16);  %Cut the lowest correlation; cp = cut position
                cp=sort(cp, 'descend');
                
                for i=1:(16-nfs)
                    rdf( cp(i), :)= [];
                    coorf( :, cp(i))= [];
                    intenf (cp(i))=[];
                end
            end
            % ending of cut
            
            cb=(7-b)/2; nos=b*b;
            
            for i=1:1:nfs
                for j=1:1:9
                    patchdiff= ff(y-3+coorf(2,i)-3+cb:1:y+3+coorf(2,i)-3-cb,x-3+coorf(1,i)-3+cb:1:x+3+coorf(1,i)-3-cb) - final(y-3+coord(2,j)-3+cb:1:y+3+coord(2,j)-3-cb,x-3+coord(1,j)-3+cb:1:x+3+coord(1,j)-3-cb);
                    rdf(i,j)=rdf3x3_2( (sum(sum(patchdiff.*patchdiff))/nos), var);
                end
            end
            
            rff=zeros(nfs,nfs);
            for i=1:1:nfs
                for j=1:1:nfs
                    patchdiff= ff(y-3+coorf(2,i)-3+cb:1:y+3+coorf(2,i)-3-cb,x-3+coorf(1,i)-3+cb:1:x+3+coorf(1,i)-3-cb) - ff(y-3+coorf(2,j)-3+cb:1:y+3+coorf(2,j)-3-cb,x-3+coorf(1,j)-3+cb:1:x+3+coorf(1,j)-3-cb);
                    rff(i,j)=rdf3x3_2( (sum(sum(patchdiff.*patchdiff))/nos), var);
                end
            end
            
            noiselessV= max(0.1,(sum(intenf.*intenf))/16- noiseV);
            I=eye(nfs, nfs);
            regP= (noiseV/noiselessV);
            
            W=(rff+regP*I)\(rdf);
            sw=sum(W);
            for i=1:1:9
                W(:,i)= W(:,i)/sw(i);
            end
            
            z(:,:,xx)=reshape(intenf*W, 3,3)';
            
            for p=1:3
                for pp=1:3
                    if z(p, pp, xx)<0
                        z(p, pp, xx)=0;
                    elseif z(p, pp, xx)>255
                        z(p, pp, xx)=255;
                    end
                end
            end
        end
    end
    validy(yy,:)=valid16(1,:);
    zz(:,:,:,yy)= z(:,:,:);
    
end

for yy=2+dd:1:sy+ad-dd
    y=yy*3+1;
    for xx=2+dd:1:sx+ad-dd
        x=xx*3+1;
        if sum( sum(isfinite(zz(:,:,xx,yy))))==9  && validy(yy,xx)==1
            final(y:1:y+2,x:1:x+2)= zz(:,:,xx,yy) ;
        end
    end
end

output=final(pd+1:syy+pd, pd+1:sxx+pd);

return;

%%
