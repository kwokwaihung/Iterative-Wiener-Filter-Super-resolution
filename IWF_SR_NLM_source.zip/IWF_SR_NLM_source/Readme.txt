% Kwok-Wai Hung, Wan-Chi Siu, Single-Image Super-Resolution Using Iterative Wiener Filter based on Nonlocal Means
%
% Module Leader: Prof. W.C. Siu, PhD, CEng, FIEE, FHKIE, FIEEE, Chair Professor
%
% PhD Researcher: Dr. K.W. Hung, PhD
%
% Version 1.0
% - Initial release
%
% 1). Please cite the following paper when you use the code:
%
%  Kwok-Wai Hung, Wan-Chi Siu, Single-Image Super-Resolution Using Iterative Wiener Filter based on Nonlocal Means, Signal Processing: Image Communication, Vol. 39, Part A, pp 26-45, November 2015. 
%
% 2). The current version of the program only support gray level image, 3x SR factor and noise variance 0-100.
%
% 3). This program support multi-threading, use the following commands if needed: matlabpool(7); %matlabpool close; parpool('local',7);
