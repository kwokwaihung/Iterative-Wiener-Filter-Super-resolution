function rdf=rdf3x3_2(z,m)

rdf=(exp(-z/m)); 

return;


